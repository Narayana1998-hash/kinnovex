import React from 'react';
import { Cloud, Shield, Brain, Code, Users, Zap, DollarSign, Building, Leaf, UserCheck, Target, ShoppingCart, Settings, Palette, UserPlus, GraduationCap } from 'lucide-react';

const ServicesSection = () => {
  const services = [
    {
      id: 1,
      icon: <Cloud className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Cloud Solutions",
      description: "Scalable infrastructure and cloud migration for the modern enterprise.",
      keyServices: ["Cloud Architecture & Deployment", "Hybrid & Multi-cloud Solutions", "Cloud Migration Services", "DevOps & CI/CD Integration"],
      techStack: "AWS, Azure, GCP | UX/UI Design & SAP Cloud Integration",
      cta: "Get Cloud Assessment"
    },
    {
      id: 2,
      icon: <Shield className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Cybersecurity",
      description: "End-to-end security for your digital assets and business continuity.",
      keyServices: ["Threat Detection & Response", "Cloud & Network Security", "Compliance Management", "Zero Trust Architecture"],
      techStack: "IT Infrastructure & Managed Security Services",
      cta: "Security Assessment"
    },
    {
      id: 3,
      icon: <Brain className="w-8 h-8 text-[#1FB6FF]" />,
      title: "AI & Data Intelligence",
      description: "Turn data into decisions with AI-powered insights.",
      keyServices: ["Predictive Analytics & BI", "Machine Learning Models", "Data Warehousing & Lakehouse", "Cognitive Process Automation"],
      techStack: "SAP Analytics & UX Dashboards",
      cta: "Explore AI Solutions"
    },
    {
      id: 4,
      icon: <Code className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Digital Engineering",
      description: "Building scalable, modern applications for every platform.",
      keyServices: ["Web & Mobile App Development", "UX/UI Design & Prototyping", "API Integration & DevOps", "Agile Delivery Model"],
      techStack: "Design-first Approach | Human-Centered UX",
      cta: "Start Your Project"
    },
    {
      id: 5,
      icon: <Users className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Customer Experience",
      description: "Enhance experience and loyalty through digital CX.",
      keyServices: ["Omnichannel Support Systems", "Chatbots & AI Assistants", "CRM & Ticketing Solutions"],
      techStack: "Salesforce, Freshdesk, SAP CX",
      cta: "Improve CX"
    },
    {
      id: 6,
      icon: <Zap className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Emerging Technology",
      description: "Unlock future possibilities with innovation.",
      keyServices: ["Internet of Things (IoT)", "Blockchain Solutions", "AR/VR for Enterprises", "Quantum R&D"],
      techStack: "Experimental Labs | Prototype Development",
      cta: "Explore Innovation"
    },
    {
      id: 7,
      icon: <DollarSign className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Finance & Risk",
      description: "Empowering secure, compliant, and agile finance operations.",
      keyServices: ["Fraud Detection with AI", "Digital Payments", "Risk Analytics", "Regulatory Compliance"],
      techStack: "SAP Finance & GRC Tools",
      cta: "Financial Solutions"
    },
    {
      id: 8,
      icon: <Building className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Infrastructure Projects",
      description: "Tech-led capital project management at scale.",
      keyServices: ["IT Infrastructure Deployment", "Smart City Solutions", "Industrial IoT & Automation", "Cloud-Based PMO Tools"],
      techStack: "Infrastructure Consulting",
      cta: "Infrastructure Consulting"
    },
    {
      id: 9,
      icon: <Leaf className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Sustainability",
      description: "Smart tech for a smarter, greener planet.",
      keyServices: ["Carbon Tracking & Reporting", "Green Data Centers", "Smart Energy Management"],
      techStack: "ESG Reporting | Sustainable Cloud Infrastructure",
      cta: "Green Tech Solutions"
    },
    {
      id: 10,
      icon: <UserCheck className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Talent & Organization",
      description: "Digitally transform your workforce.",
      keyServices: ["Human Capital Management", "Digital HR Platforms", "Organizational Change Design"],
      techStack: "SAP SuccessFactors | Learning Portals | UX-centric HR Apps",
      cta: "HR Transformation"
    },
    {
      id: 11,
      icon: <Target className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Strategy & Consulting",
      description: "Turn disruption into opportunity.",
      keyServices: ["Digital Transformation Roadmaps", "IT Strategy & Architecture", "Business Process Reengineering"],
      techStack: "Strategic Consulting",
      cta: "Strategic Consulting"
    },
    {
      id: 12,
      icon: <ShoppingCart className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Sales & Commerce",
      description: "Smart commerce for the digital economy.",
      keyServices: ["E-Commerce Platforms", "Mobile Commerce", "CPQ & Sales Enablement Tools"],
      techStack: "Shopify | Magento | SAP Commerce Cloud | UX/UI optimization",
      cta: "Commerce Solutions"
    },
    {
      id: 13,
      icon: <Settings className="w-8 h-8 text-[#1FB6FF]" />,
      title: "IT Services & SAP Solutions",
      description: "Comprehensive IT and SAP expertise.",
      keyServices: ["IT Infrastructure Management", "SAP ERP, HANA, and Cloud Integration", "Managed Services & 24/7 Support", "SAP Custom Module Development", "SAP Fiori UX Enhancements"],
      techStack: "SAP Consultation",
      cta: "SAP Solutions"
    },
    {
      id: 14,
      icon: <Palette className="w-8 h-8 text-[#1FB6FF]" />,
      title: "UX/UI Design Integration",
      description: "Human-centered design solutions.",
      keyServices: ["Human-Centered Design", "Interactive Prototypes", "Design Systems", "Accessibility & Mobile Responsiveness", "UI Engineering (React, Angular, Flutter, Figma)"],
      techStack: "Design Consultation",
      cta: "Design Consultation"
    },
    {
      id: 15,
      icon: <UserPlus className="w-8 h-8 text-[#1FB6FF]" />,
      title: "IT Recruitment Services",
      description: "Expert technical talent acquisition.",
      keyServices: ["Technical Talent Acquisition", "Contract & Permanent Placements", "Skills Assessment & Screening", "Technology Team Building", "Specialized IT Roles Placement"],
      techStack: "Recruitment Services",
      cta: "Recruitment Services"
    },
    {
      id: 16,
      icon: <GraduationCap className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Education Services",
      description: "Comprehensive technology training and development.",
      keyServices: ["Technology Training Programs", "Corporate Learning Solutions", "Digital Skills Development", "Certification Programs", "Custom Curriculum Development"],
      techStack: "Education Programs",
      cta: "Education Programs"
    }
  ];

  return (
    <section id="services" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Our Services
          </h2>
          <p className="font-open-sans text-white text-xl mb-4">
            Empowering Digital Transformation
          </p>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            From cloud infrastructure to AI innovation, we deliver end-to-end technology services 
            that transform businesses and drive sustainable growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-gray-900 rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2 group"
            >
              <div className="mb-4">
                {service.icon}
              </div>
              <h3 className="font-montserrat font-bold text-white text-lg mb-3 uppercase">
                {service.title}
              </h3>
              <p className="font-open-sans text-gray-300 text-sm mb-4 leading-relaxed">
                {service.description}
              </p>
              <div className="mb-4">
                <h4 className="font-montserrat font-bold text-[#1FB6FF] text-xs uppercase mb-2">
                  Key Services:
                </h4>
                <ul className="space-y-1 max-h-24 overflow-hidden">
                  {service.keyServices.slice(0, 3).map((item, index) => (
                    <li key={index} className="font-open-sans text-gray-400 text-xs">
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mb-6">
                <h4 className="font-montserrat font-bold text-[#1FB6FF] text-xs uppercase mb-2">
                  Tech Stack:
                </h4>
                <p className="font-open-sans text-gray-400 text-xs">
                  {service.techStack}
                </p>
              </div>
              <button className="w-full bg-[#1FB6FF] text-black px-4 py-2 rounded-lg font-montserrat font-bold text-xs uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
                {service.cta}
              </button>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <button className="bg-black border-2 border-[#1FB6FF] text-[#1FB6FF] px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-[#1FB6FF] hover:text-black hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Ready to Transform Your Business?
          </button>
          <p className="font-open-sans text-gray-300 text-lg mt-4">
            Let's discuss how our comprehensive technology solutions can accelerate your digital transformation journey.
          </p>
          <button className="mt-6 bg-[#1FB6FF] text-black px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-white hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Start Your Transformation
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;