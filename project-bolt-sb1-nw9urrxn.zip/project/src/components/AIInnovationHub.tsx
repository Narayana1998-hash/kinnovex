import React from 'react';
import { Brain, Bot, Truck, Wrench } from 'lucide-react';

const AIInnovationHub = () => {
  const aiServices = [
    {
      id: 1,
      icon: <Brain className="w-12 h-12 text-[#1FB6FF]" />,
      title: "Generative AI",
      description: "Content creation, intelligent agents, automation",
      services: ["Copywriting Bots", "AI Assistants", "Image & Video Generation"],
      poweredBy: "GPT Models, Stable Diffusion"
    },
    {
      id: 2,
      icon: <Bot className="w-12 h-12 text-[#1FB6FF]" />,
      title: "AI-Powered Robotics",
      description: "Smart automation for industrial and retail spaces",
      services: ["Autonomous Warehouse Bots", "Delivery Drones", "Vision-based Quality Inspection"],
      poweredBy: "Computer Vision, ML"
    },
    {
      id: 3,
      icon: <Truck className="w-12 h-12 text-[#1FB6FF]" />,
      title: "Autonomous Supply Chains",
      description: "Self-optimizing and self-healing supply chains",
      services: ["Demand Forecasting", "Inventory Optimization", "AI Logistics Routing"],
      poweredBy: "Predictive Analytics"
    },
    {
      id: 4,
      icon: <Wrench className="w-12 h-12 text-[#1FB6FF]" />,
      title: "AI Refinery",
      description: "AI-enhanced marketing and process optimization",
      services: ["Smart Campaign Management", "Production Intelligence", "Predictive Maintenance"],
      poweredBy: "Machine Learning"
    }
  ];

  return (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            AI INNOVATION HUB
          </h2>
          <p className="font-open-sans text-white text-xl mb-4">
            Leading the AI Revolution
          </p>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            Harness the power of artificial intelligence to transform your business operations, 
            enhance customer experiences, and drive unprecedented growth.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {aiServices.map((service) => (
            <div
              key={service.id}
              className="bg-gray-900 rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2 group"
            >
              <div className="mb-4">
                {service.icon}
              </div>
              <h3 className="font-montserrat font-bold text-white text-xl mb-3 uppercase">
                {service.title}
              </h3>
              <p className="font-open-sans text-gray-300 text-sm mb-4">
                {service.description}
              </p>
              <div className="mb-4">
                <h4 className="font-montserrat font-bold text-[#1FB6FF] text-sm uppercase mb-2">
                  Services:
                </h4>
                <ul className="space-y-1">
                  {service.services.map((item, index) => (
                    <li key={index} className="font-open-sans text-gray-400 text-sm">
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mb-6">
                <h4 className="font-montserrat font-bold text-[#1FB6FF] text-sm uppercase mb-2">
                  Powered by:
                </h4>
                <p className="font-open-sans text-gray-400 text-sm">
                  {service.poweredBy}
                </p>
              </div>
              <button className="w-full bg-[#1FB6FF] text-black px-4 py-2 rounded-lg font-montserrat font-bold text-sm uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
                View Details
              </button>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto mb-8">
            <div className="text-center">
              <h3 className="font-montserrat font-bold text-[#1FB6FF] text-4xl md:text-5xl">95%</h3>
              <p className="font-open-sans text-white text-lg">Process Automation</p>
            </div>
            <div className="text-center">
              <h3 className="font-montserrat font-bold text-[#1FB6FF] text-4xl md:text-5xl">40%</h3>
              <p className="font-open-sans text-white text-lg">Cost Reduction</p>
            </div>
          </div>
          <button className="bg-black border-2 border-[#1FB6FF] text-[#1FB6FF] px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-[#1FB6FF] hover:text-black hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Explore Our Services
          </button>
        </div>
      </div>
    </section>
  );
};

export default AIInnovationHub;