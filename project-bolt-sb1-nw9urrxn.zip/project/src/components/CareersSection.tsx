import React from 'react';
import { Users, Lightbulb, Laptop, Heart, MapPin, Clock, DollarSign, ArrowRight } from 'lucide-react';

const CareersSection = () => {
  const benefits = [
    "Competitive salary and equity",
    "Comprehensive health insurance",
    "Flexible work arrangements",
    "Professional development budget",
    "Unlimited PTO policy",
    "State-of-the-art equipment",
    "Team building events",
    "Wellness programs"
  ];

  const positions = [
    {
      id: 1,
      title: "Senior Full Stack Developer",
      department: "Engineering",
      location: "Remote",
      experience: "5+ years",
      type: "Full-time"
    },
    {
      id: 2,
      title: "AI/ML Engineer",
      department: "Data Science",
      location: "Remote",
      experience: "3+ years",
      type: "Full-time"
    },
    {
      id: 3,
      title: "Cloud Solutions Architect",
      department: "Infrastructure",
      location: "Remote",
      experience: "7+ years",
      type: "Full-time"
    },
    {
      id: 4,
      title: "UX/UI Designer",
      department: "Design",
      location: "Remote",
      experience: "4+ years",
      type: "Full-time"
    },
    {
      id: 5,
      title: "DevOps Engineer",
      department: "Infrastructure",
      location: "Remote",
      experience: "4+ years",
      type: "Full-time"
    },
    {
      id: 6,
      title: "Product Manager",
      department: "Product",
      location: "Remote",
      experience: "5+ years",
      type: "Full-time"
    }
  ];

  const highlights = [
    {
      icon: <Users className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Collaborative Teams",
      description: "Work with diverse, talented teams on cutting-edge projects"
    },
    {
      icon: <Lightbulb className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Innovation Focus",
      description: "Lead innovation in AI, cloud computing, and emerging technologies"
    },
    {
      icon: <Laptop className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Latest Technology",
      description: "Access to the latest tools, technologies, and learning resources"
    },
    {
      icon: <Heart className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Work-Life Balance",
      description: "Flexible schedules and remote work options for better balance"
    }
  ];

  return (
    <section id="careers" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Join Our Innovative Team
          </h2>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            Be part of a dynamic team that's shaping the future of technology. We're looking for passionate 
            individuals who want to make a real impact.
          </p>
        </div>

        {/* Why Work With Us */}
        <div className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {highlights.map((highlight, index) => (
              <div
                key={index}
                className="bg-gray-900 rounded-lg p-6 text-center hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2"
              >
                <div className="flex justify-center mb-4">
                  {highlight.icon}
                </div>
                <h3 className="font-montserrat font-bold text-white text-lg mb-3 uppercase">
                  {highlight.title}
                </h3>
                <p className="font-open-sans text-gray-300 text-sm">
                  {highlight.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits */}
        <div className="mb-16">
          <h3 className="font-montserrat font-bold text-white text-3xl uppercase mb-8 text-center">
            Work With Us
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="bg-gray-900 rounded-lg p-4 text-center hover:bg-gray-800 transition-all duration-300"
              >
                <p className="font-open-sans text-white text-sm font-semibold">
                  {benefit}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Open Positions */}
        <div className="mb-16">
          <h3 className="font-montserrat font-bold text-white text-3xl uppercase mb-8 text-center">
            Open Positions
          </h3>
          <div className="space-y-4">
            {positions.map((position) => (
              <div
                key={position.id}
                className="bg-gray-900 rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_20px_rgba(31,182,255,0.3)]"
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div className="flex-1">
                    <h4 className="font-montserrat font-bold text-white text-xl mb-2">
                      {position.title}
                    </h4>
                    <div className="flex flex-wrap items-center gap-4 text-gray-400 text-sm">
                      <div className="flex items-center space-x-1">
                        <Users className="w-4 h-4" />
                        <span>{position.department}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MapPin className="w-4 h-4" />
                        <span>{position.location}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{position.experience}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <DollarSign className="w-4 h-4" />
                        <span>{position.type}</span>
                      </div>
                    </div>
                  </div>
                  <button className="mt-4 md:mt-0 bg-[#1FB6FF] text-black px-6 py-2 rounded-lg font-montserrat font-bold text-sm uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300 flex items-center space-x-2">
                    <span>Apply Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gray-900 rounded-lg p-8">
          <h3 className="font-montserrat font-bold text-white text-2xl mb-4">
            Don't see a position that fits?
          </h3>
          <p className="font-open-sans text-gray-300 text-lg mb-6">
            We're always looking for talented individuals to join our team.
          </p>
          <button className="bg-[#1FB6FF] text-black px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-white hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Send Us Your Resume
          </button>
        </div>
      </div>
    </section>
  );
};

export default CareersSection;