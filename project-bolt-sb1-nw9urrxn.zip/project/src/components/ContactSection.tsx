import React, { useState } from 'react';
import { Mail, Phone, Calendar, MapPin, Linkedin, Youtube, Instagram, Twitter, Facebook, Shield } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    company: '',
    phone: '',
    service: '',
    projectDetails: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const services = [
    "Cloud Solutions",
    "Cybersecurity", 
    "AI & Data Intelligence",
    "Digital Engineering",
    "Customer Experience",
    "Emerging Technology",
    "Finance & Risk",
    "Infrastructure Projects",
    "Sustainability",
    "Talent & Organization",
    "Strategy & Consulting",
    "Sales & Commerce",
    "IT Services & SAP Solutions",
    "UX/UI Design Integration",
    "IT Recruitment Services",
    "Education Services"
  ];

  return (
    <section id="contact" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Let's Start Your Digital Journey
          </h2>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            Transforming ideas into impactful digital realities through innovative, scalable, and future-ready 
            technology solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <div className="space-y-8 mb-12">
              <div className="flex items-start space-x-4">
                <div className="bg-[#1FB6FF] p-3 rounded-lg">
                  <Mail className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-montserrat font-bold text-white text-xl mb-2">Email Us</h3>
                  <p className="font-open-sans text-gray-300 mb-2">Get a response within 24 hours</p>
                  <a href="mailto:contact@kinnovex.com" className="font-open-sans text-[#1FB6FF] hover:text-white transition-colors">
                    contact@kinnovex.com
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-[#1FB6FF] p-3 rounded-lg">
                  <Phone className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-montserrat font-bold text-white text-xl mb-2">Call Us</h3>
                  <p className="font-open-sans text-gray-300 mb-2">Speak with our experts directly</p>
                  <a href="tel:+919989946655" className="font-open-sans text-[#1FB6FF] hover:text-white transition-colors">
                    +91 99899 46655
                  </a>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-[#1FB6FF] p-3 rounded-lg">
                  <Calendar className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-montserrat font-bold text-white text-xl mb-2">Schedule Meeting</h3>
                  <p className="font-open-sans text-gray-300 mb-2">Free 30-minute strategy session</p>
                  <button className="font-open-sans text-[#1FB6FF] hover:text-white transition-colors">
                    Book Consultation
                  </button>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-[#1FB6FF] p-3 rounded-lg">
                  <MapPin className="w-6 h-6 text-black" />
                </div>
                <div>
                  <h3 className="font-montserrat font-bold text-white text-xl mb-2">Office Address</h3>
                  <p className="font-open-sans text-gray-300">
                    Flat No: 326, 3rd Floor<br />
                    Urban Studio Lake Front Apartments<br />
                    Mahalakshmi Nagar, Manikonda<br />
                    Gachibowli, Hyderabad<br />
                    Telangana 500075
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media */}
            <div>
              <h3 className="font-montserrat font-bold text-white text-xl mb-4">Connect with us</h3>
              <div className="flex space-x-4">
                <a href="#" className="bg-gray-800 p-3 rounded-lg hover:bg-[#1FB6FF] hover:text-black transition-colors">
                  <Linkedin className="w-5 h-5" />
                </a>
                <a href="#" className="bg-gray-800 p-3 rounded-lg hover:bg-[#1FB6FF] hover:text-black transition-colors">
                  <Youtube className="w-5 h-5" />
                </a>
                <a href="#" className="bg-gray-800 p-3 rounded-lg hover:bg-[#1FB6FF] hover:text-black transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="#" className="bg-gray-800 p-3 rounded-lg hover:bg-[#1FB6FF] hover:text-black transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
                <a href="#" className="bg-gray-800 p-3 rounded-lg hover:bg-[#1FB6FF] hover:text-black transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-black rounded-lg p-8">
            <div className="flex items-center space-x-2 mb-6">
              <Shield className="w-5 h-5 text-[#1FB6FF]" />
              <p className="font-open-sans text-gray-300 text-sm">
                Your information is secure and will never be shared with third parties
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="fullName" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  id="fullName"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="Enter your full name"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors"
                  required
                />
              </div>

              <div>
                <label htmlFor="email" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="Enter your email"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors"
                  required
                />
              </div>

              <div>
                <label htmlFor="company" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Company
                </label>
                <input
                  type="text"
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleChange}
                  placeholder="Your company name"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors"
                />
              </div>

              <div>
                <label htmlFor="phone" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="Your phone number"
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors"
                />
              </div>

              <div>
                <label htmlFor="service" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Service Interest *
                </label>
                <select
                  id="service"
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#1FB6FF] transition-colors"
                  required
                >
                  <option value="">Select a service</option>
                  {services.map((service, index) => (
                    <option key={index} value={service}>{service}</option>
                  ))}
                </select>
              </div>

              <div>
                <label htmlFor="projectDetails" className="block font-montserrat font-bold text-white text-sm uppercase mb-2">
                  Project Details *
                </label>
                <textarea
                  id="projectDetails"
                  name="projectDetails"
                  value={formData.projectDetails}
                  onChange={handleChange}
                  placeholder="Tell us about your project requirements..."
                  rows={4}
                  className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors resize-none"
                  required
                />
                <p className="text-gray-400 text-sm mt-1">{formData.projectDetails.length}/500</p>
              </div>

              <button
                type="submit"
                className="w-full bg-[#1FB6FF] text-black px-6 py-3 rounded-lg font-montserrat font-bold uppercase hover:bg-white hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300"
              >
                Send Message & Get Free Consultation
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="font-open-sans text-gray-300 text-sm">
                <span className="font-bold text-[#1FB6FF]">Quick Response Guarantee:</span> We typically respond 
                to all inquiries within 24 hours. For urgent matters, please call us directly for immediate assistance.
              </p>
            </div>
          </div>
        </div>

        {/* Newsletter Subscription */}
        <div className="mt-20 bg-black rounded-lg p-8 text-center">
          <h3 className="font-montserrat font-bold text-white text-2xl mb-4">
            Stay Ahead of the Curve
          </h3>
          <p className="font-open-sans text-gray-300 text-lg mb-6">
            Subscribe to our newsletter for the latest insights on technology trends, industry updates, 
            and innovative solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your business email"
              className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-[#1FB6FF] transition-colors"
            />
            <button className="bg-[#1FB6FF] text-black px-6 py-3 rounded-lg font-montserrat font-bold uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
              Subscribe
            </button>
          </div>
          <p className="font-open-sans text-gray-400 text-sm mt-4">
            Join 10,000+ technology leaders. Unsubscribe anytime.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;