import React from 'react';
import { Calendar, User, Clock, ArrowRight } from 'lucide-react';

const InsightsSection = () => {
  const insights = [
    {
      id: 1,
      title: "The Future of AI in Enterprise Solutions",
      description: "Exploring how artificial intelligence is transforming enterprise operations and driving innovation across industries.",
      author: "Naveen",
      date: "April 15, 2025",
      readTime: "5 min",
      category: "AI Enterprise Innovation",
      featured: true
    },
    {
      id: 2,
      title: "Cloud Migration Strategies for Modern Businesses",
      description: "A comprehensive guide to successful cloud migration strategies and best practices for modern enterprises.",
      author: "Tech Team",
      date: "May 1, 2025",
      readTime: "7 min",
      category: "Cloud Migration Strategy"
    },
    {
      id: 3,
      title: "Cybersecurity in the Age of Remote Work",
      description: "Understanding the evolving cybersecurity landscape and protecting your business in a remote-first world.",
      author: "Security Team",
      date: "May 10, 2025",
      readTime: "6 min",
      category: "Cybersecurity Remote Work Protection"
    },
    {
      id: 4,
      title: "Digital Transformation Success Stories",
      description: "Real-world examples of successful digital transformation initiatives and their impact on business growth.",
      author: "Strategy Team",
      date: "June 15, 2025",
      readTime: "8 min",
      category: "Digital Transformation Case Studies"
    },
    {
      id: 5,
      title: "The Rise of Low-Code Development Platforms",
      description: "How low-code platforms are democratizing software development and accelerating digital innovation.",
      author: "Development Team",
      date: "July 3, 2025",
      readTime: "4 min",
      category: "Low-Code Development Innovation"
    },
    {
      id: 6,
      title: "Sustainable Technology: Green IT Solutions",
      description: "Exploring sustainable technology solutions and their role in creating a greener digital future.",
      author: "Sustainability Team",
      date: "July 20, 2025",
      readTime: "6 min",
      category: "Sustainability Green Tech Environment"
    }
  ];

  const categories = [
    "Industry Reports",
    "Market Insights", 
    "Innovation Stories"
  ];

  return (
    <section id="insights" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Latest Insights
          </h2>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            Stay ahead with our latest thoughts on technology trends, industry insights, and innovative 
            solutions shaping the future of business.
          </p>
        </div>

        {/* Categories */}
        <div className="flex justify-center mb-12">
          <div className="flex flex-wrap gap-4">
            {categories.map((category, index) => (
              <div
                key={index}
                className="bg-black rounded-lg px-6 py-3 border border-gray-700"
              >
                <p className="font-montserrat font-bold text-[#1FB6FF] text-sm uppercase">
                  {category}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Featured Article */}
        {insights.filter(insight => insight.featured).map((insight) => (
          <div
            key={insight.id}
            className="bg-black rounded-lg p-8 mb-12 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transition-all duration-300"
          >
            <div className="flex flex-wrap items-center gap-2 mb-4">
              <span className="bg-[#1FB6FF] text-black px-3 py-1 rounded-full font-montserrat font-bold text-xs uppercase">
                Featured
              </span>
              <span className="text-gray-400 text-sm font-open-sans">
                {insight.category}
              </span>
            </div>
            <h3 className="font-montserrat font-bold text-white text-2xl md:text-3xl mb-4">
              {insight.title}
            </h3>
            <p className="font-open-sans text-gray-300 text-lg mb-6 leading-relaxed">
              {insight.description}
            </p>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 text-gray-400 text-sm">
                <div className="flex items-center space-x-1">
                  <User className="w-4 h-4" />
                  <span>{insight.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{insight.date}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{insight.readTime}</span>
                </div>
              </div>
              <button className="flex items-center space-x-2 bg-[#1FB6FF] text-black px-4 py-2 rounded-lg font-montserrat font-bold text-sm uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
                <span>Read More</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        {/* Regular Articles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {insights.filter(insight => !insight.featured).map((insight) => (
            <div
              key={insight.id}
              className="bg-black rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2"
            >
              <div className="mb-4">
                <span className="text-[#1FB6FF] text-xs font-montserrat font-bold uppercase">
                  {insight.category}
                </span>
              </div>
              <h3 className="font-montserrat font-bold text-white text-xl mb-3">
                {insight.title}
              </h3>
              <p className="font-open-sans text-gray-300 text-sm mb-6 leading-relaxed">
                {insight.description}
              </p>
              <div className="flex items-center justify-between text-gray-400 text-xs mb-4">
                <div className="flex items-center space-x-1">
                  <User className="w-3 h-3" />
                  <span>{insight.author}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-3 h-3" />
                  <span>{insight.date}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>{insight.readTime}</span>
                </div>
              </div>
              <button className="w-full bg-[#1FB6FF] text-black px-4 py-2 rounded-lg font-montserrat font-bold text-sm uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
                Read Article
              </button>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <button className="bg-black border-2 border-[#1FB6FF] text-[#1FB6FF] px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-[#1FB6FF] hover:text-black hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Load More Articles
          </button>
        </div>
      </div>
    </section>
  );
};

export default InsightsSection;