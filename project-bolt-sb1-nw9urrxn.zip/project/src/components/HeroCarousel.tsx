import React, { useState, useEffect } from 'react';

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      id: 1,
      headline: "INNOVATE WITH KINNOVEX",
      subtext: "Empowering enterprises with cutting-edge technology solutions and strategic innovation to drive digital transformation and sustainable growth.",
      cta: "Transform, Lead, Drive Digital Evolution"
    },
    {
      id: 2,
      headline: "Transforming Business Through Innovation",
      subtext: "We empower enterprises to thrive in the digital age. We are a leading technology solutions and strategic innovation partner, committed to driving impactful digital transformation and sustainable growth for businesses worldwide.",
      cta: "Engineering Tomorrow's Digital Reality"
    },
    {
      id: 3,
      headline: "Unleash the Power of Quantum AI",
      subtext: "Fusing the power of Artificial Intelligence and Quantum Computing to unlock next-generation optimization, prediction, and simulation—accelerating breakthroughs in science, business, and technology with Speed, precision, and next-gen intelligence redefined.",
      cta: "Innovation, Digital Transformation, Future-Readiness"
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="relative h-screen w-full bg-black overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 flex items-center justify-center transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="text-center max-w-6xl mx-auto px-6">
            <h1 className="font-montserrat font-bold text-white text-4xl md:text-6xl lg:text-7xl uppercase mb-8 leading-tight tracking-wide">
              {slide.headline}
            </h1>
            <p className="font-open-sans text-white text-lg md:text-xl lg:text-2xl mb-12 max-w-4xl mx-auto leading-relaxed">
              {slide.subtext}
            </p>
            <button className="bg-black border-2 border-white text-white px-8 py-4 rounded-full font-montserrat font-bold uppercase tracking-wide hover:bg-white hover:text-black hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300 transform hover:scale-105">
              {slide.cta}
            </button>
          </div>
        </div>
      ))}
      
      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? 'bg-[#1FB6FF] scale-125' : 'bg-white/50 hover:bg-white/75'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;