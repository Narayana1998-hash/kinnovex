import React from 'react';
import { Phone } from 'lucide-react';

const Navigation = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <span className="text-white text-2xl font-bold tracking-wide">KINNOVEX</span>
          </div>
          
          {/* Navigation Menu */}
          <div className="hidden lg:flex items-center space-x-8">
            <a href="#home" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              HOME
            </a>
            <a href="#services" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              SERVICES
            </a>
            <a href="#industries" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              INDUSTRIES WE SERVE
            </a>
            <a href="#about" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              ABOUT US
            </a>
            <a href="#insights" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              INSIGHTS
            </a>
            <a href="#careers" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              CAREERS
            </a>
            <a href="#contact" className="text-white hover:text-[#1FB6FF] transition-colors duration-300 font-montserrat font-bold text-sm uppercase tracking-wide">
              CONTACT US
            </a>
          </div>
          
          {/* Phone Number */}
          <div className="flex items-center space-x-2 text-white">
            <Phone className="w-4 h-4" />
            <span className="font-semibold">+91 99899 46655</span>
          </div>
          
          {/* Mobile menu button */}
          <div className="lg:hidden">
            <button className="text-white hover:text-[#1FB6FF] transition-colors duration-300">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;