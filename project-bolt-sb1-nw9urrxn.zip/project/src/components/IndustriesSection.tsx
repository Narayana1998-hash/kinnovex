import React from 'react';
import { Car, Building2, Factory, Heart, Cpu, Shield, Zap, Truck, TrendingUp, ShoppingBag, Users, Laptop } from 'lucide-react';

const IndustriesSection = () => {
  const industries = [
    {
      id: 1,
      icon: <Car className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Automotive",
      description: "Advanced manufacturing, supply chain optimization, and smart mobility solutions."
    },
    {
      id: 2,
      icon: <Building2 className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Banking & Financial Services",
      description: "Digital banking, fraud detection, regulatory compliance, and fintech innovation."
    },
    {
      id: 3,
      icon: <Factory className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Manufacturing",
      description: "Industry 4.0, IoT integration, predictive maintenance, and smart factory solutions."
    },
    {
      id: 4,
      icon: <Heart className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Healthcare & Life Sciences",
      description: "Digital health platforms, medical data analytics, and compliance management."
    },
    {
      id: 5,
      icon: <Cpu className="w-8 h-8 text-[#1FB6FF]" />,
      title: "High Tech & IT",
      description: "Product development, cloud-native solutions, and technology consulting."
    },
    {
      id: 6,
      icon: <Shield className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Insurance",
      description: "Digital claims processing, risk assessment, and customer experience enhancement."
    },
    {
      id: 7,
      icon: <Zap className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Energy & Utilities",
      description: "Smart grid technology, renewable energy management, and sustainability solutions."
    },
    {
      id: 8,
      icon: <Truck className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Supply Chain & Logistics",
      description: "End-to-end visibility, autonomous logistics, and demand forecasting."
    },
    {
      id: 9,
      icon: <TrendingUp className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Capital Markets",
      description: "Trading platforms, risk management, and regulatory technology solutions."
    },
    {
      id: 10,
      icon: <ShoppingBag className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Consumer Goods & Retail",
      description: "E-commerce platforms, inventory optimization, and customer analytics."
    },
    {
      id: 11,
      icon: <Users className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Public Sector & Government",
      description: "Digital governance, citizen services, and smart city initiatives."
    },
    {
      id: 12,
      icon: <Laptop className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Software & Creative Tech",
      description: "Product development, creative workflows, and digital content platforms."
    }
  ];

  return (
    <section id="industries" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Industries
          </h2>
          <p className="font-open-sans text-white text-xl mb-4">
            Tailored Industry Solutions
          </p>
          <p className="font-open-sans text-gray-300 text-lg max-w-3xl mx-auto">
            Our expertise spans across diverse industries, delivering tailored solutions with deep domain 
            expertise that address unique challenges and opportunities in each sector.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {industries.map((industry) => (
            <div
              key={industry.id}
              className="bg-black rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2 group"
            >
              <div className="mb-4">
                {industry.icon}
              </div>
              <h3 className="font-montserrat font-bold text-white text-lg mb-3 uppercase">
                {industry.title}
              </h3>
              <p className="font-open-sans text-gray-300 text-sm mb-6 leading-relaxed">
                {industry.description}
              </p>
              <button className="w-full bg-[#1FB6FF] text-black px-4 py-2 rounded-lg font-montserrat font-bold text-sm uppercase hover:bg-white hover:shadow-[0_0_20px_rgba(31,182,255,0.5)] transition-all duration-300">
                View Details
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IndustriesSection;