import React from 'react';

const Footer = () => {
  const serviceLinks = [
    "Cloud Solutions", "Cybersecurity", "AI & Data Intelligence", "Digital Engineering",
    "Customer Experience", "Emerging Technology", "Finance & Risk", "Infrastructure Projects",
    "Sustainability", "Talent & Organization", "Strategy & Consulting", "Sales & Commerce",
    "IT Services & SAP Solutions", "UX/UI Design Integration", "IT Recruitment Services", "Education Services"
  ];

  const industryLinks = [
    "Automotive", "Banking & Financial Services", "Manufacturing", "Healthcare & Life Sciences",
    "High Tech & IT", "Insurance", "Energy & Utilities", "Supply Chain & Logistics",
    "Capital Markets", "Consumer Goods & Retail", "Public Sector & Government", "Software & Creative Tech"
  ];

  return (
    <footer className="bg-black py-16 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="font-montserrat font-bold text-white text-2xl mb-4 tracking-wide">
              KINNOVEX
            </h3>
            <p className="font-open-sans text-gray-300 text-sm mb-6 leading-relaxed">
              Empowering transformation through innovative technology solutions.
            </p>
            <div className="space-y-2">
              <p className="font-open-sans text-gray-300 text-sm">
                <span className="font-bold">Contact:</span><br />
                contact@kinnovex.com<br />
                +91 99899 46655
              </p>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-montserrat font-bold text-white text-lg uppercase mb-4">
              Services
            </h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {serviceLinks.map((service, index) => (
                <a
                  key={index}
                  href={`#${service.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-')}`}
                  className="block font-open-sans text-gray-400 text-sm hover:text-[#1FB6FF] transition-colors"
                >
                  {service}
                </a>
              ))}
            </div>
          </div>

          {/* Industries */}
          <div>
            <h4 className="font-montserrat font-bold text-white text-lg uppercase mb-4">
              Industries
            </h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {industryLinks.map((industry, index) => (
                <a
                  key={index}
                  href={`#${industry.toLowerCase().replace(/ & /g, '-').replace(/ /g, '-')}`}
                  className="block font-open-sans text-gray-400 text-sm hover:text-[#1FB6FF] transition-colors"
                >
                  {industry}
                </a>
              ))}
            </div>
          </div>

          {/* Office Address */}
          <div>
            <h4 className="font-montserrat font-bold text-white text-lg uppercase mb-4">
              Office Address
            </h4>
            <div className="font-open-sans text-gray-300 text-sm leading-relaxed">
              <p>
                Flat No: 326, 3rd Floor<br />
                Urban Studio Lake Front Apartments<br />
                Mahalakshmi Nagar, Manikonda<br />
                Gachibowli, Hyderabad<br />
                Telangana 500075
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex space-x-6 mb-4 md:mb-0">
              <a href="#" className="font-open-sans text-gray-400 text-sm hover:text-[#1FB6FF] transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="font-open-sans text-gray-400 text-sm hover:text-[#1FB6FF] transition-colors">
                Terms of Service
              </a>
              <a href="#" className="font-open-sans text-gray-400 text-sm hover:text-[#1FB6FF] transition-colors">
                Cookie Policy
              </a>
            </div>
            <p className="font-open-sans text-gray-400 text-sm">
              © 2025 Kinnovex. All Rights Reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;