import React from 'react';
import { Target, Eye, Lightbulb, Users, Award, Zap } from 'lucide-react';

const AboutSection = () => {
  const values = [
    {
      icon: <Lightbulb className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Innovation-Driven",
      description: "We embrace cutting-edge technologies and creative solutions to solve complex business challenges."
    },
    {
      icon: <Users className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Client Obsession",
      description: "Our clients' success is our success. We go above and beyond to exceed expectations."
    },
    {
      icon: <Award className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Integrity & Transparency",
      description: "We build trust through honest communication and ethical business practices."
    },
    {
      icon: <Target className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Operational Excellence",
      description: "We deliver consistent, high-quality results through proven methodologies and best practices."
    },
    {
      icon: <Users className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Collaborative Culture",
      description: "We foster teamwork, knowledge sharing, and inclusive environments for innovation."
    },
    {
      icon: <Zap className="w-8 h-8 text-[#1FB6FF]" />,
      title: "Agility & Growth Mindset",
      description: "We adapt quickly to change and continuously learn to stay ahead of the curve."
    }
  ];

  const whyChooseUs = [
    "Automation & Digital Transformation Experts",
    "AMAZING IT Professionals",
    "GLOBAL PRESENCE",
    "ISO 27001 CERTIFIED",
    "100% Client Satisfaction",
    "Cutting-edge technology solutions",
    "Scalable and future-ready architectures",
    "Industry-specific expertise and insights",
    "24/7 support and maintenance services"
  ];

  return (
    <section id="about" className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-6">
        {/* Vision */}
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <Eye className="w-16 h-16 text-[#1FB6FF]" />
          </div>
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Our Vision
          </h2>
          <p className="font-open-sans text-gray-300 text-lg md:text-xl max-w-4xl mx-auto leading-relaxed">
            To be a globally trusted technology partner, empowering businesses of all sizes through innovative, 
            scalable, and future-ready solutions that accelerate digital transformation and sustainable growth.
          </p>
        </div>

        {/* Mission */}
        <div className="text-center mb-20">
          <div className="flex justify-center mb-6">
            <Target className="w-16 h-16 text-[#1FB6FF]" />
          </div>
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Our Mission
          </h2>
          <p className="font-open-sans text-gray-300 text-lg md:text-xl max-w-4xl mx-auto leading-relaxed">
            At Kinnovex, our mission is to simplify complexity and enable transformation. We deliver bespoke, 
            end-to-end digital solutions that address real-world challenges, drive innovation, and create lasting value. 
            Backed by cutting-edge technology, a skilled and passionate team, and an unwavering client-first approach, 
            we transform ideas into impactful digital realities.
          </p>
        </div>

        {/* Values */}
        <div className="mb-20">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-12 text-center">
            Our Values
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-gray-900 rounded-lg p-6 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_30px_rgba(31,182,255,0.3)] transform hover:-translate-y-2"
              >
                <div className="mb-4">
                  {value.icon}
                </div>
                <h3 className="font-montserrat font-bold text-white text-xl mb-3 uppercase">
                  {value.title}
                </h3>
                <p className="font-open-sans text-gray-300 text-sm leading-relaxed">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Why Choose Us */}
        <div className="text-center">
          <h2 className="font-montserrat font-bold text-white text-4xl md:text-5xl uppercase mb-6">
            Why Choose Us
          </h2>
          <p className="font-open-sans text-white text-xl mb-12">
            Your Trusted Technology Partner
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {whyChooseUs.map((reason, index) => (
              <div
                key={index}
                className="bg-gray-900 rounded-lg p-4 hover:bg-gray-800 transition-all duration-300 hover:shadow-[0_0_20px_rgba(31,182,255,0.3)]"
              >
                <p className="font-open-sans text-white text-sm font-semibold">
                  {reason}
                </p>
              </div>
            ))}
          </div>
          <button className="mt-12 bg-[#1FB6FF] text-black px-8 py-3 rounded-full font-montserrat font-bold uppercase hover:bg-white hover:shadow-[0_0_30px_rgba(31,182,255,0.5)] transition-all duration-300">
            Start Your Transformation
          </button>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;