import React from 'react';
import Navigation from './components/Navigation';
import HeroCarousel from './components/HeroCarousel';
import AIInnovationHub from './components/AIInnovationHub';
import ServicesSection from './components/ServicesSection';
import IndustriesSection from './components/IndustriesSection';
import AboutSection from './components/AboutSection';
import InsightsSection from './components/InsightsSection';
import CareersSection from './components/CareersSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Navigation />
      <main>
        <HeroCarousel />
        <AIInnovationHub />
        <ServicesSection />
        <IndustriesSection />
        <AboutSection />
        <InsightsSection />
        <CareersSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;